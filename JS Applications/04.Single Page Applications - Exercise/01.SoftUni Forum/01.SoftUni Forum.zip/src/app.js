import { homeView } from "./home.js";

document.getElementById('home-btn').addEventListener('click', homeView);

homeView();